# views.py

from django.shortcuts import render,get_object_or_404
from .models import BlogPost


def home(request):
    return render(request, 'home.html')

def about(request):
    return render(request, 'about.html')

def horoscope(request):
    return render(request, 'horoscope.html')

def numerology(request):
    return render(request, 'numerology.html')

def tarot(request):
    return render(request, 'tarot.html')

def love(request):
    return render(request, 'love.html')

def blog(request):
    return render(request, 'blog.html')

def base(request):
    return render(request,'base.html')


def home(request):
    latest_posts = BlogPost.objects.order_by('-created_at')[:5]  # Get the 5 latest blog posts
    return render(request, 'home.html', {'latest_posts': latest_posts})


# for horoscope.html page
# views.py
from django.shortcuts import render
from django.http import JsonResponse
from .models import Horoscope  # Assuming you have a Horoscope model

def get_zodiac_data(request, zodiac_sign):
    # Fetch data from the database based on the selected zodiac sign
    horoscope_data = Horoscope.objects.get(zodiac_sign=zodiac_sign)

    # Prepare the data to be sent back to the client
    data = {
        'zodiac_sign': horoscope_data.zodiac_sign,
        'content': horoscope_data.content,
        # Add more fields as needed
    }

    # Return the data as a JSON response
    return JsonResponse(data)


# for new_page_blog_post
def blog_post_detail(request, pk):
    post = get_object_or_404(BlogPost, pk=pk)
    return render(request, 'blog_post_detail.html', {'post': post})

# for horoscope blog page
def Horoscope_blog_post_detail(request, pk):
    post = get_object_or_404(BlogPost, pk=pk)
    return render(request, 'Horoscope_blog_post_detail.html', {'post': post})