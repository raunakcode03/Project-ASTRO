# admin.py

from django.contrib import admin
from .models import BlogPost
from .models import ZodiacContent

admin.site.register(BlogPost)
admin.site.register(ZodiacContent)