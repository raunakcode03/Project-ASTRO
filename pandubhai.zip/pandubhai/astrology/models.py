# astrology/models.py

from django.db import models

class AstrologicalSign(models.Model):
    name = models.CharField(max_length=50)
    element = models.CharField(max_length=20)
    planet = models.CharField(max_length=50)
    description = models.TextField()

    def __str__(self):
        return self.name

class Horoscope(models.Model):
    sign = models.ForeignKey(AstrologicalSign, on_delete=models.CASCADE)
    date = models.DateField()
    prediction = models.TextField()

    def __str__(self):
        return f"{self.date} - {self.sign}"

# home/models.py

from django.db import models

class BlogPost(models.Model):
    title = models.CharField(max_length=200)
    image = models.ImageField(upload_to='blog_images/', null=True, blank=True)
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title

# horoscope/models.py

from django.db import models

class ZodiacContent(models.Model):
    sign = models.CharField(max_length=50)
    content = models.TextField()

    def __str__(self):
        return self.sign
