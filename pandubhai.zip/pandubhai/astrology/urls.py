# urls.py

from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('about/', views.about, name='about'),
    path('horoscope/', views.horoscope, name='horoscope'),
    path('numerology/', views.numerology, name='numerology'),
    path('tarot/', views.tarot, name='tarot'),
    path('love/', views.love, name='love'),
    path('blog/', views.blog, name='blog'),
    path('base/', views.base, name='base'),
    path('blog/<int:pk>/', views.blog_post_detail, name='blog_post_detail'),
    path('blog/<int:pk>/', views.Horoscope_blog_post_detail, name='Horoscope_blog_post_detail'),

]
